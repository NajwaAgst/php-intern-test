<?php
$pattern = [
    "X 0 0 0 0 0 X",
    "0 X 0 0 0 X 0",
    "0 0 X 0 X 0 0",
    "0 0 0 X 0 0 0",
    "0 0 X 0 X 0 0",
    "0 X 0 0 0 X 0",
    "X 0 0 0 0 0 X",
];

foreach ($pattern as $line) {
    echo $line . PHP_EOL;
}
?>